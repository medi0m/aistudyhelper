async function askAI() {
  const question = document.getElementById("question").value;
  const answerDiv = document.getElementById("answer");
  answerDiv.innerText = "Thinking...";

  try {
    const response = await fetch("/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question })
    });

    const data = await response.json();
    answerDiv.innerText = data.answer || "No response from AI.";
  } catch (error) {
    answerDiv.innerText = "Error: " + error.message;
  }
}
